BROKER_PATH="${0/run-broker.sh/broker//bin}"
cd "$BROKER_PATH"
./broker